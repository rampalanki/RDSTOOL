 var DMselectedNew ;
var DMdesc;
var BselectedNew;
var BselectedNewdesc;
var selbtype;
var selDsec;
sap.ui.define(["sap/m/Button",
		"sap/m/Label",
		'sap/m/Dialog',
			'jquery.sap.global',
					'sap/m/MessageBox',
		'sap/ui/core/Fragment',
			'sap/m/MessageToast',
		"sap/ui/core/mvc/Controller",
			'sap/ui/model/Filter',
  "sap/ui/model/FilterOperator",
  "sap/ui/model/FilterType",
					'sap/ui/model/ValidateException',
		"sap/ui/model/json/JSONModel"
], function (Button, Label, Dialog, jQuery, MessageBox, Fragment, MessageToast, Controller, Filter, FilterOperator, FilterType, ValidateException, JSONModel) {
	"use strict";
		
	return Controller.extend("com.prowess.zRDSFioriScreen.controller.Search", {
			oModel:null,
			oModelN:null,
	oModel1:null,
	oModel2:null,
	oModel4:null,
	oModelS:null,
    oModelO:null,
		onInit: function () {
//debugger;
			this.oModel = new JSONModel("model/SearchCriteria.json");
			this.getView().setModel(this.oModel);
			
			this.SearchModel = new JSONModel();
			this.getView().setModel(this.SearchModel);
			// this.oModel.refresh();
			this.oModel1 = new JSONModel("model/Template.json");
			this.getView().setModel(this.oModel1,"template");
			
			this.oModel2 = new JSONModel("model/Block.json");
			this.getView().setModel(this.oModel2,"block"); 
			
			this.oModel3 = new JSONModel("model/BlockType.json");
			this.getView().setModel(this.oModel3,"blocktype");
			
			this.oModel4 = new JSONModel("model/DataModel.json");
			this.getView().setModel(this.oModel4,"datamodel"); 
			
			this.oModelN = new JSONModel();
			this.getView().setModel(this.oModelN,"new");
			
			 this.oModelS = new JSONModel("model/SearchBy.json");
            this.getView().setModel(this.oModelS,"sel");
       
            this.oModelO = new JSONModel("model/Operator.json");
            this.getView().setModel(this.oModelO,"opr");
            
           
			this.getView().byId("tableSearchResult").setVisible(true);
			},
			loaddialog:function(){
				 if(!this._oDialogTemp){ 
		this._oDialogTemp = sap.ui.xmlfragment("templateFrag","com.prowess.zRDSFioriScreen.view.Template", this);
				this.getView().addDependent(this._oDialogTemp);
            }
             if(!this._oDialogB){
		this._oDialogB = sap.ui.xmlfragment("blockFrag","com.prowess.zRDSFioriScreen.view.Block", this);
				this.getView().addDependent(this._oDialogB);
             }
             if(!this._oDialogDM){
            this._oDialogDM = sap.ui.xmlfragment("dataModelFrag","com.prowess.zRDSFioriScreen.view.DataModel", this);
				this.getView().addDependent(this._oDialogDM);
            }
			},
		deletewarning:function(oEventd){
			var that=this;
			var oTableid = this.getView().byId("tableSearchResult");
				 var aSelectedItemscount = oTableid.getSelectedItems();
				 if(aSelectedItemscount!=""){
				MessageBox.warning(
				"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						if(sAction=="OK"){
					that.handleDelete();
						}else{
						}
					}
				}
			);
				 }else{
				 		MessageBox.warning(	"Please Select atleast one option");
				 		}
				},
		handleDelete : function (oEventd) {
			//debugger;
					var bCopy=	this.getView().byId('copyTem');var delitems=[];
		var bDelete =	this.getView().byId('deleteTem');
				var oTabled = this.getView().byId("tableSearchResult");
				 var aSelectedItems = oTabled.getSelectedItems();
				  var search=[];
				 	var modelData=this.oModel.getProperty("/SearchCriteria");
				 for(var i=0;i<modelData.length;i++){
				 	for(var j=0;j<aSelectedItems.length;j++){
				 		var idx = oTabled.indexOfItem(aSelectedItems[j]);
				 	
				 	if(modelData[i].Template==aSelectedItems[j].mAggregations.cells[0].mProperties.text && 
				 		modelData[i].Block==aSelectedItems[j].mAggregations.cells[2].mProperties.text && 
				 		modelData[i].DataModel==aSelectedItems[j].mAggregations.cells[3].mProperties.text){
				 		search.push(idx);
				 	}
				 	}
				 }
				 	for(var k=search.length-1;k>=0;k--){
				 		this.searchitems.splice(search[k], 1);
				 	}
				 	if(oTabled!=undefined)
				 	oTabled.removeSelections();
				 		this.SearchModel.setData({"Searchitems":this.searchitems});
				 		this.getView().setModel(this.SearchModel);
	
if(oTabled.getItems().length!=0){
    
  bCopy.setEnabled(true);
			bDelete.setEnabled(true); 
}		else{
	   	 bCopy.setEnabled(false);
			bDelete.setEnabled(false); 
}	  
		},
			
		onClear : function () {
				var id1,id2,id3;
			var that=this;
					var st1=this.getView().byId("selectT1").getSelectedItem();
					var s1=	st1.mProperties.text;
				this.getView().byId("selectT1").setSelectedKey(1);
				this.getView().byId("selectB1").setSelectedKey(2);
				this.getView().byId("selectDM1").setSelectedKey(3);
				this.getView().byId("selectT2").setSelectedKey(1);
				this.getView().byId("selectB2").setSelectedKey(1);
				this.getView().byId("selectDM2").setSelectedKey(1);
				this.getView().byId("selectT3").setVisible();
				this.getView().byId("selectB3").setVisible();
				this.getView().byId("selectDM3").setVisible();
				sap.ui.core.Fragment.byId("templateFrag","tT1").setVisible(true);
				sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").setVisible(true);
				sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").removeSelections(true);
				sap.ui.core.Fragment.byId("templateFrag","tB1").setVisible(false);
				sap.ui.core.Fragment.byId("templateFrag","tableBlock1").setVisible(false);
				sap.ui.core.Fragment.byId("templateFrag","tableBlock1").removeSelections(true);
				sap.ui.core.Fragment.byId("templateFrag","tDM1").setVisible(false);
				sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").setVisible(false);
				sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").removeSelections(true);
				sap.ui.core.Fragment.byId("blockFrag","tB2").setVisible(true);
                sap.ui.core.Fragment.byId("blockFrag","tableBlock2").setVisible(true);
                sap.ui.core.Fragment.byId("blockFrag","tableBlock2").removeSelections(true);
                sap.ui.core.Fragment.byId("blockFrag","tT2").setVisible(false);
                sap.ui.core.Fragment.byId("blockFrag","tableTemplate2").setVisible(false);
                sap.ui.core.Fragment.byId("blockFrag","tableTemplate2").removeSelections(true);
                sap.ui.core.Fragment.byId("blockFrag","tDM2").setVisible(false);
                sap.ui.core.Fragment.byId("blockFrag","tableDataMod2").setVisible(false);
                sap.ui.core.Fragment.byId("blockFrag","tableDataMod2").removeSelections(true);
				sap.ui.core.Fragment.byId("dataModelFrag","tDM3").setVisible(true);
                sap.ui.core.Fragment.byId("dataModelFrag","tableDataMod3").setVisible(true);
                sap.ui.core.Fragment.byId("dataModelFrag","tableDataMod3").removeSelections(true);
                sap.ui.core.Fragment.byId("dataModelFrag","tB3").setVisible(false);
                sap.ui.core.Fragment.byId("dataModelFrag","tableBlock3").setVisible(false);
                sap.ui.core.Fragment.byId("dataModelFrag","tableBlock3").removeSelections(true);
                sap.ui.core.Fragment.byId("dataModelFrag","tT3").setVisible(false);
                sap.ui.core.Fragment.byId("dataModelFrag","tableTemplate3").setVisible(false);
                sap.ui.core.Fragment.byId("dataModelFrag","tableTemplate3").removeSelections(true);
				
						if(s1=="Template"){
						id1= "tableTemplate1";		
					}else if(s1=="Block"){
	 id1= "tableBlock1";
					}	
			else if(s1=="DataModel"){
					id1= "tableDataMod1";
							} 
			
						var st2=this.getView().byId("selectB1").getSelectedItem();
					var s2=	st2.mProperties.text;
				if(s2=="Block"){
	 id2= "tableBlock2";
					}else if(s2=="DataModel"){
					id2= "tableDataMod2";
							}else if(s2=="Template"){
						id2= "tableTemplate2";		
					}
							var st3=this.getView().byId("selectDM1").getSelectedItem();
					var s3=	st3.mProperties.text;
				if(s3=="DataModel"){
					id3= "tableDataMod3";
					}else if(s3=="Block"){
						 id3= "tableBlock3";
							}else if(s3=="Template"){
						id3= "tableTemplate3";		
					}
			var ipTemp=	this.getView().byId('selectT3');
			 ipTemp.setValue(null);
			 	var ipBlock=	this.getView().byId('selectB3');
			 ipBlock.setValue(null);
			 	var ipDataModel=	this.getView().byId('selectDM3');
			 ipDataModel.setValue(null);
			  var oTableTem = sap.ui.getCore().byId(id1);
			  if(oTableTem!=undefined)
				oTableTem.removeSelections(true);
				  var oTableBloc = sap.ui.getCore().byId(id2);
				  if(oTableBloc!=undefined)
				oTableBloc.removeSelections(true);
				  var oTableDM = sap.ui.getCore().byId(id3);
				  if(oTableDM!=undefined)
				oTableDM.removeSelections(true);
				
				
		},
	
		onSearch : function (oEvt) {
		//	debugger;
		this.getView().byId("p2").setExpanded(true);
		var bCopy1=	this.getView().byId('copyTem');
		var bDelete1=	this.getView().byId('deleteTem');
	 
				var op1 =this.getView().byId("selectT3");
				var des = this.getView().byId("tDesc");
				var op2 = this.getView().byId("selectB3");
			//	var op3 = this.getView().byId("selectBT3");
				var op4 = this.getView().byId("selectDM3");
				
				var template1=this.getView().byId("selectT1").getSelectedItem().getText();
				var template2=this.getView().byId("selectB1").getSelectedItem().getText();
				var template3=this.getView().byId("selectDM1").getSelectedItem().getText();
				
				var operator1=this.getView().byId("selectT2").getSelectedItem().getText();
				var operator2=this.getView().byId("selectB2").getSelectedItem().getText();
				var operator3=this.getView().byId("selectDM2").getSelectedItem().getText();
			

			var v1=	(op1.mProperties.value).toUpperCase();
				var v2=	des.mProperties.text;
				var v3=	(op2.mProperties.value).toUpperCase();
				//var t4=	op3.mProperties.value;
				var v5=	(op4.mProperties.value).toUpperCase();
				var t1,t3,t5;
				if(template1=="Template"){
				      t1=v1;
				}else if(template1=="Block"){
					 t3=v1;
				}else if(template1=="DataModel"){
					 t5=v1;
				}
				if(template2=="Template"){
				      t1=v3;
				}else if(template2=="Block"){
					 t3=v3;
				}else if(template2=="DataModel"){
					 t5=v3;
				}
				if(template3=="Template"){
				      t1=v5;
				}else if(template3=="Block"){
					 t3=v5;
				}else if(template3=="DataModel"){
					 t5=v5;
				}
			
				if(operator1=="is empty"){
					t1="";
				}
				if(operator2=="is empty"){
					t3="";
				}
				if(operator3=="is empty"){
					t5="";
				}
				this.searchitems=[];
				var modelData=this.oModel.getProperty("/SearchCriteria");
				 for(var i=0;i<modelData.length;i++){
				 	if(( operator1=="is" && operator2=="is" && operator3=="is") || ( operator1=="is" && operator2=="is empty" && operator3=="is empty") 
				 	|| ( operator1=="is empty" && operator2=="is" && operator3=="is empty") || ( operator1=="is empty" && operator2=="is empty" && operator3=="is")	){
				 	if(modelData[i].Template==t1 && modelData[i].Block==t3 && modelData[i].DataModel==t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is" && operator2=="is not" && operator3=="is not") || (operator1=="is" && operator2=="is not" && operator3=="is empty") 
				 			 || (operator1=="is" && operator2=="is empty" && operator3=="is not") || (operator1=="is empty" && operator2=="is not" && operator3=="is not")){
				 		if(modelData[i].Template==t1 && modelData[i].Block!=t3 && modelData[i].DataModel!=t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is not" && operator2=="is" && operator3=="is not") || (operator1=="is not" && operator2=="is empty" && operator3=="is not")
				 		|| (operator1=="is empty" && operator2=="is" && operator3=="is not") || (operator1=="is not" && operator2=="is" && operator3=="is empty")){
				 		if(modelData[i].Template!=t1 && modelData[i].Block==t3 && modelData[i].DataModel!=t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is not" && operator2=="is" && operator3=="is") || (operator1=="is empty" && operator2=="is" && operator3=="is")
				 			|| (operator1=="is not" && operator2=="is empty" && operator3=="is") || (operator1=="is not" && operator2=="is" && operator3=="is empty")){
				 		if(modelData[i].Template!=t1 && modelData[i].Block==t3 && modelData[i].DataModel==t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is" && operator2=="is not" && operator3=="is") || (operator1=="is empty" && operator2=="is not" && operator3=="is")
				 				|| (operator1=="is" && operator2=="is empty" && operator3=="is") || (operator1=="is" && operator2=="is not" && operator3=="is empty")){
				 		if(modelData[i].Template==t1 && modelData[i].Block!=t3 && modelData[i].DataModel==t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is" && operator2=="is" && operator3=="is not") || (operator1=="is empty" && operator2=="is" && operator3=="is not")
				 			|| (operator1=="is" && operator2=="is empty" && operator3=="is not") || (operator1=="is" && operator2=="is" && operator3=="is empty")){
				 		if(modelData[i].Template==t1 && modelData[i].Block==t3 && modelData[i].DataModel!=t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template==t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block==t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if((operator1=="is not" && operator2=="is not" && operator3=="is") || (operator1=="is empty" && operator2=="is not" && operator3=="is")
				 		|| (operator1=="is not" && operator2=="is empty" && operator3=="is") || (operator1=="is not" && operator2=="is not" && operator3=="is empty")){
				 		if(modelData[i].Template!=t1 && modelData[i].Block!=t3 && modelData[i].DataModel==t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel==t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if(( operator1=="is not" && operator2=="is not" && operator3=="is not") || ( operator1=="is not" && operator2=="is empty" && operator3=="is empty") 
				 	|| ( operator1=="is empty" && operator2=="is not" && operator3=="is empty") || ( operator1=="is empty" && operator2=="is empty" && operator3=="is not")){
				 	if(modelData[i].Template!=t1 && modelData[i].Block!=t3 && modelData[i].DataModel!=t5){
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(modelData[i].Template!=t1 && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && modelData[i].Block!=t3 && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && modelData[i].DataModel!=t5){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}else if(t1=="" && t3=="" && t5==""){
				 			this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	}
				 	}else if( operator1=="is empty" && operator2=="is empty" && operator3=="is empty"){
				 	//
				 		this.searchitems.push({"Template":modelData[i].Template ,
				 									"Description":modelData[i].Description,
				 									"Block":modelData[i].Block ,
				 									"BlockType":modelData[i].BlockType ,
				 									"DataModel":modelData[i].DataModel});
				 	//}
				 	}
				 }	
				 		this.SearchModel.setData({"Searchitems":this.searchitems});
       var oBinding = this.byId("tableSearchResult").getBinding("items");
       //this.getView().byId("tableSearchResultdup").setVisible(false);
if(oBinding.iLength!='0'){
		 bCopy1.setEnabled(true);
			bDelete1.setEnabled(true);   
}else{
	  bCopy1.setEnabled(false);
			bDelete1.setEnabled(false); 
}
this.getView().byId("tableSearchResult").setVisible(true);
		},
		pressblockV: function () {   
      		         var b=0;
                var c = 0;
                 var bNew = sap.ui.getCore().byId("inputB1New");
                var n3=    (bNew.mProperties.value).toUpperCase();
      			var cnt2=this.oModel2.oData.Block.length;
                        sap.ui.getCore().byId("err2").setVisible(false);
            for(var i=0;i<cnt2;i++){       
    if(n3==this.oModel2.oData.Block[i].Block){
        c++;
        b++;
    }
    }    if( c!=1 && b!=1 ){
						 		sap.ui.getCore().byId("err2").setVisible(false);
		
        sap.ui.getCore().byId("err5").setVisible(true);   
        }
		},
		pressdatamodelV: function (){	
     var dm=0; 
      var dmNew = sap.ui.getCore().byId("inputDM1New");
     var n5=    (dmNew.mProperties.value).toUpperCase();
                var c = 0;
            var cnt3=this.oModel4.oData.DataModel.length;
                        for(var i=0;i<cnt3;i++){       
    if(n5==this.oModel4.oData.DataModel[i].Model){
    	var DMselDsec=this.oModel4.oData.DataModel[i].Description;
        c++;
        dm++;
    }
    }
    if( dm!=1 && c!=2 ){
						sap.ui.getCore().byId("err3").setVisible(false);
				
        sap.ui.getCore().byId("err6").setVisible(true);   
        }
		},
		_getDialogn : function () {
			
			if (!this._oDialogn) {
				this._oDialogn = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.newTemplate", this);
				this.getView().addDependent(this._oDialogn);
			}
			return this._oDialogn;
		},
		
		handleCreate: function () {
		//    debugger;
                var oTableN = this.getView().byId("tableSearchResult");
                 var nSelectedItems = oTableN.getSelectedItems();
                 if(nSelectedItems.length == 0){
                     this.getView().byId("errNew").setVisible(false);
                     this._getDialogn().open();
            sap.ui.getCore().byId("inputTemplate").setValue();
            sap.ui.getCore().byId("inputB1New").setSelectedItem();
            sap.ui.getCore().byId("inputDM1New").setSelectedItem();
            sap.ui.getCore().byId("bDescN").setText();
            sap.ui.getCore().byId("dmDescN").setText();
            sap.ui.getCore().byId("err1").setVisible(false);
            sap.ui.getCore().byId("err2").setVisible(false);
            sap.ui.getCore().byId("err3").setVisible(false);
            //sap.ui.getCore().byId("err4").setVisible(false);
            sap.ui.getCore().byId("bDescN").setVisible(false);
            sap.ui.getCore().byId("dmDescN").setVisible(false);
           
                       var oTableBloc1= sap.ui.getCore().byId('tableBlockNew');
                       if(oTableBloc1!=undefined)
                oTableBloc1.removeSelections(true);    
                  var oTableDM1 = sap.ui.getCore().byId('tableDataModelNew');
                  if(oTableDM1!=undefined)
                oTableDM1.removeSelections(true);
               
                     }else if(nSelectedItems.length != 0){
                     this.getView().byId("errNew").setVisible(true);   
                 }
		},
				pressOkn: function () {
			//    debugger;
			//var that=this;
                var cnt1=this.oModel1.oData.Template.length;
        		var cnt2=this.oModel2.oData.Block.length;
            var cnt3=this.oModel4.oData.DataModel.length;
           var b=0; var dm=0; var c = 0;
           
                var temN =sap.ui.getCore().byId("inputTemplate");
                var tdesN = sap.ui.getCore().byId("bDescNew");
                
                var bNew = sap.ui.getCore().byId("inputB1New");
            //    var op3 = this.getView().byId("selectBT3");
                var dmNew = sap.ui.getCore().byId("inputDM1New");
    	var bDes = sap.ui.getCore().byId("bDescN");
        var dmDes = sap.ui.getCore().byId("dmDescN");
       
       var n1=    (temN.mProperties.value).toUpperCase();
                var n2=    temN.mProperties.text;
                var n3=    (bNew.mProperties.value).toUpperCase();
                var n7=    bNew.mProperties.text;
                //var t4=    op3.mProperties.value;
                var n5=    (dmNew.mProperties.value).toUpperCase();
                    if (n5=="" && n1=="" && n3==""){
					  sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                   
                         sap.ui.getCore().byId("err1").setVisible(true);   
                         sap.ui.getCore().byId("err2").setVisible(true);
                         sap.ui.getCore().byId("err3").setVisible(true);
                       // sap.ui.getCore().byId("err4").setVisible(false);
                           }
                if (n5!="" && n1=="" && n3!=""){
				  sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                    
                        sap.ui.getCore().byId("err1").setVisible(true);
                        sap.ui.getCore().byId("err2").setVisible(false);
                        sap.ui.getCore().byId("err3").setVisible(false);
                      //this.pressblockV();
                      //this.pressdatamodelV();
                          }else if(n5!="" && n1!="" && n3==""){
					
                            sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                
                            sap.ui.getCore().byId("err1").setVisible(false);
                        sap.ui.getCore().byId("err2").setVisible(true);
                        sap.ui.getCore().byId("err3").setVisible(false);
                      //this.pressdatamodelV();
                    }else if(n5=="" && n1!="" && n3!=""){
					
                            sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                
                        sap.ui.getCore().byId("err1").setVisible(false);
                        sap.ui.getCore().byId("err2").setVisible(false);
                        sap.ui.getCore().byId("err3").setVisible(true);
                      //this.pressblockV();
                           }else if(n5=="" && n1=="" && n3!=""){
					
                            sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                   
                            sap.ui.getCore().byId("err1").setVisible(true);
                        sap.ui.getCore().byId("err2").setVisible(false);
                        sap.ui.getCore().byId("err3").setVisible(true);
                     //this.pressblockV();
                        }else if(n5!="" && n1=="" && n3==""){
					   sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                  
                        sap.ui.getCore().byId("err1").setVisible(true);
                        sap.ui.getCore().byId("err2").setVisible(true);
                        sap.ui.getCore().byId("err3").setVisible(false);
                      //  sap.ui.getCore().byId("err4").setVisible(false);
                       //this.pressdatamodelV();
                           }else if(n5=="" && n1!="" && n3==""){
					
                            sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                   
                            sap.ui.getCore().byId("err1").setVisible(false);
                        sap.ui.getCore().byId("err2").setVisible(true);
                        sap.ui.getCore().byId("err3").setVisible(true);
                     //   sap.ui.getCore().byId("err4").setVisible(false);
                        }   
			  if (n5!="" && n1!="" && n3!="") {
                       
                        sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                       
                        sap.ui.getCore().byId("err1").setVisible(false);
                        sap.ui.getCore().byId("err2").setVisible(false);
                        sap.ui.getCore().byId("err3").setVisible(false);
                     //   sap.ui.getCore().byId("err4").setVisible(false);
                        if(n3!=""){
                           
                        sap.ui.getCore().byId("err2").setVisible(false);
            for(var i=0;i<cnt2;i++){       
    if(n3==this.oModel2.oData.Block[i].Block){
    	// var selDsec=this.oModel2.oData.Block[i].Description;
        c++;
        b++;
    }
    }    if( c!=1 && b!=1 ){
	sap.ui.getCore().byId("err6").setVisible(false);
						 			sap.ui.getCore().byId("err1").setVisible(false);
						 		sap.ui.getCore().byId("err2").setVisible(false);
						sap.ui.getCore().byId("err3").setVisible(false);
					//	sap.ui.getCore().byId("err4").setVisible(false);
		
        sap.ui.getCore().byId("err5").setVisible(true);   
        }
		}
    if(n5!=""){
       
                       // sap.ui.getCore().byId("err3").setVisible(false);
                        for(var i=0;i<cnt3;i++){       
    if(n5==this.oModel4.oData.DataModel[i].Model){
    	var DMselDsec=this.oModel4.oData.DataModel[i].Description;
        c++;
        dm++;
    }
    }
    if( dm!=1 && c!=2 ){
	sap.ui.getCore().byId("err1").setVisible(false);
						 		sap.ui.getCore().byId("err2").setVisible(false);
						sap.ui.getCore().byId("err3").setVisible(false);
					//	sap.ui.getCore().byId("err4").setVisible(false);
		
        sap.ui.getCore().byId("err6").setVisible(true);   
        }
		}
	// this.pressblockV();
 //                     this.pressdatamodelV();
                         if ( c == 2 && dm==1 && b ==1) {
						 
            sap.ui.getCore().byId("err5").setVisible(false);
            sap.ui.getCore().byId("err6").setVisible(false);
                                     sap.ui.getCore().byId("err1").setVisible(false);
                                 sap.ui.getCore().byId("err2").setVisible(false);
                        sap.ui.getCore().byId("err3").setVisible(false);
                      //  sap.ui.getCore().byId("err4").setVisible(false);
                       var blockname=sap.ui.getCore().byId("inputB1New").getValue().toUpperCase();
                       for(var i=0;i<this.oModel3.oData.BlockType.length;i++){
				 	if(this.oModel3.oData.BlockType[i].Block==blockname){
				 		selbtype=this.oModel3.oData.BlockType[i].BlockType;
				 		selDsec=this.oModel3.oData.BlockType[i].Description;
				 	}else{
				 		selbtype="";
				 		selDsec="";
				 	}
				 	}
            sap.ui.getCore()._templatedialogvlaue = sap.ui.getCore().byId("inputTemplate").getValue().toUpperCase();
             sap.ui.getCore()._blockdialogvalue = blockname.toUpperCase();
            sap.ui.getCore()._blocktypedialogvalue = selbtype.toUpperCase();
            sap.ui.getCore()._datamodeldialogvalue = sap.ui.getCore().byId("inputDM1New").getValue().toUpperCase();
            // sap.ui.getCore()._btdescriptiondialogvalue=sap.ui.getCore().byId("bDescN").getText();
            //sap.ui.getCore()._dmdialogvalue=sap.ui.getCore().byId("dmDescN").getText();
             sap.ui.getCore()._btdescriptiondialogvalue=selDsec;
            sap.ui.getCore()._dmdialogvalue=DMselDsec;
            if(sap.ui.getCore()._mode=="repeat"){
            sap.ui.getCore().panelid1=sap.ui.getCore()._panelid1;
            sap.ui.getCore().panelid2=sap.ui.getCore()._panelid2;
            sap.ui.getCore().templateid=sap.ui.getCore()._templateid.sId;
            sap.ui.getCore().btypeid=sap.ui.getCore()._btypeid.sId;
            sap.ui.getCore().dmodelid=sap.ui.getCore()._dmodelid.sId;
            sap.ui.getCore().tdesc1id=sap.ui.getCore()._tdesc1id.sId;
            sap.ui.getCore().tdesc2id=sap.ui.getCore()._tdesc2id.sId;
            sap.ui.controller("com.prowess.zRDSFioriScreen.controller.UIBB").gettemplateform();
            }
            // this._oDialogTemp.close();
            // this._oDialogB.close();
            // this._oDialogDM.close();
  var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.navTo("UIBB");
        }   
                    }
                },

					onClosen: function () {
						this._oDialogn.close();
        sap.ui.getCore().byId("err5").setVisible(false);
                        sap.ui.getCore().byId("err6").setVisible(false);
                  
                         sap.ui.getCore().byId("err1").setVisible(false);  
                         sap.ui.getCore().byId("err2").setVisible(false);
                         sap.ui.getCore().byId("err3").setVisible(false);
                      //  sap.ui.getCore().byId("err4").setVisible(false);
        sap.ui.getCore().byId("inputTemplate").setValue();
            sap.ui.getCore().byId("inputB1New").setValue();
            sap.ui.getCore().byId("inputDM1New").setValue();
				
		},

						_getDialogBlockNew : function () {
			if (!this._oDialogBNew) {
				this._oDialogBNew = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.BlockNew", this);
				this.getView().addDependent(this._oDialogBNew);
			}
			return this._oDialogBNew;
		},
		
		onBlockNew: function () {
			this._getDialogBlockNew().open();
		},
		
		onSelectBlockNew :  function (oEvent1) {
	//		debugger;
						var that=this;
					//	var BselectedNew;
						var outcomeN = sap.ui.getCore().byId("inputB1New");
							   var oTablebNew = sap.ui.getCore().byId('tableBlockNew');
							 var selectedItemsN = oTablebNew.getSelectedItems().map(function(item) {

						 BselectedNew = item.mAggregations.cells[0].mProperties.text;
						  BselectedNewdesc = item.mAggregations.cells[1].mProperties.text;
					
						 	return item.mAggregations;

						 });
				outcomeN.setValue(BselectedNew);
			},
		onCloseBNew: function () {
		this._oDialogBNew.close();
		sap.ui.getCore().byId("err2").setVisible(false);
		},

					_getDialogDataModelNew : function () {
			if (!this._oDialogDMNew) {
				this._oDialogDMNew = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.DataModelNew", this);
				this.getView().addDependent(this._oDialogDMNew);
			}
			return this._oDialogDMNew;
		},
				onDataModelNew: function () {
			this._getDialogDataModelNew().open();
		},
			onSelectDataModelNew :  function (oEvent1) {
						var that=this;
						var outcomeDMNew = sap.ui.getCore().byId("inputDM1New");
							   var oTableDMNew = sap.ui.getCore().byId('tableDataModelNew');
						     var selectedItems = oTableDMNew.getSelectedItems().map(function(item) {
		
	 DMselectedNew = item.mAggregations.cells[0].mProperties.text;
	 DMdesc = item.mAggregations.cells[1].mProperties.text;
return item.mAggregations;

 });
 outcomeDMNew.setValue(DMselectedNew);
 
},
						onCloseDMNew: function () {
		this._oDialogDMNew.close();
		sap.ui.getCore().byId("err3").setVisible(false);
		},	
		
				_getDialogCopy : function () {
			if (!this._oDialogC) {
				this._oDialogC = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.copyTemplate", this);
				this.getView().addDependent(this._oDialogC);
			}
			return this._oDialogC;
		},
		handleCopy: function () {
			 var oTableC = this.getView().byId("tableSearchResult");
                 var nSelectedItems = oTableC.getSelectedItems();
                 if(nSelectedItems.length == 0){
                     this.getView().byId("errcopy").setVisible(true);
                 }else{
                     this.getView().byId("errcopy").setVisible(false);
                 }
        //    this._getDialogCopy().open();
		},
		pressOkc: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("UIBB");
		},
		onCloseC: function () {
		this._oDialogC.close();
		},
		
				_getDialogTemplate : function () {
			// if (!this._oDialogTemp) {
			// 	this._oDialogTemp = sap.ui.xmlfragment("templateFrag","com.prowess.zRDSFioriScreen.view.Template", this);
			// 	this.getView().addDependent(this._oDialogTemp);
			// }
			// return this._oDialogTemp;
		},
				onTemplate: function () {
					var that=this;
					that.loaddialog();
		this._oDialogTemp.open();
		},
		onSelectTemplate1 :  function (oEvent1) {
	//		debugger;
		var st1=this.getView().byId("selectT1").getSelectedItem();
		var s1=	st1.mProperties.text;
		var id1,frgid;
				if(s1=="Template"){
						id1= "tableTemplate1";
						frgid="templateFrag";
					}else if(s1=="Block"){
	 id1= "tableBlock1";
	 	frgid="blockFrag";
					}	
			else if(s1=="DataModel"){
					id1= "tableDataMod1";
						frgid="dataModelFrag";
							} 
						var Tselected,Tdesc;
						var outcome2 = this.getView().byId("tDesc");
						var outcome1 = this.getView().byId("selectT3");
						var oTablest = sap.ui.core.Fragment.byId("templateFrag",id1);
						     var selectedItems = oTablest.getSelectedItems().map(function(item) {

 Tselected = item.mAggregations.cells[0].mProperties.text;
     Tdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
// outcome1.setValue(Tselected);
// outcome2.setText(Tdesc);
this.firstfield=Tselected;
 this.firstfielddesc=Tdesc;
  this.dialogid1=id1;
 this.dialogfragid1=frgid;
},
	onSelectTemplate2 :  function (oEvent1) {
	//		debugger;
			var st2=this.getView().byId("selectB1").getSelectedItem();
					var s2=	st2.mProperties.text;
		var id1,frgid;
				if(s2=="Template"){
						id1= "tableTemplate2";
						frgid="templateFrag";
					}else if(s2=="Block"){
	 id1= "tableBlock2";
	 	frgid="blockFrag";
					}	
			else if(s2=="DataModel"){
					id1= "tableDataMod2";
						frgid="dataModelFrag";
							} 
						var Tselected,Tdesc;
						var outcome2 = this.getView().byId("bDesc");
						var outcome1 = this.getView().byId("selectB3");
						var oTablest = sap.ui.core.Fragment.byId("blockFrag",id1);
						     var selectedItems = oTablest.getSelectedItems().map(function(item) {

 Tselected = item.mAggregations.cells[0].mProperties.text;
     Tdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
// outcome1.setValue(Tselected);
// outcome2.setText(Tdesc);
this.secondfield=Tselected;
 this.secondfielddesc=Tdesc;
  this.dialogid2=id1;
 this.dialogfragid2=frgid;
},
	onSelectTemplate3 :  function (oEvent1) {
	//		debugger;
			var st3=this.getView().byId("selectDM1").getSelectedItem();
					var s3=	st3.mProperties.text;
		var id1,frgid;
				if(s3=="Template"){
						id1= "tableTemplate3";
						frgid="templateFrag";
					}else if(s3=="Block"){
	 id1= "tableBlock3";
	 	frgid="blockFrag";
					}	
			else if(s3=="DataModel"){
					id1= "tableDataMod3";
						frgid="dataModelFrag";
							} 
						var Tselected,Tdesc;
						var outcome2 = this.getView().byId("dmDesc");
						var outcome1 = this.getView().byId("selectDM3");
						var oTablest = sap.ui.core.Fragment.byId("dataModelFrag",id1);
						     var selectedItems = oTablest.getSelectedItems().map(function(item) {

 Tselected = item.mAggregations.cells[0].mProperties.text;
     Tdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
// outcome1.setValue(Tselected);
// outcome2.setText(Tdesc);
this.thirdfield=Tselected;
 this.thirdfielddesc=Tdesc;
  this.dialogid3=id1;
 this.dialogfragid3=frgid;
},
onSelectT: function () {
	this.getView().byId("selectT3").setValue(this.firstfield);
	this.getView().byId("tDesc").setText(this.firstfielddesc);
	 	this._oDialogTemp.close();
},
		onCloseT: function () {
			if(this.dialogfragid1!=undefined && this.dialogid1!=undefined)
		sap.ui.core.Fragment.byId(this.dialogfragid1,this.dialogid1).removeSelections(true);
		this._oDialogTemp.close();
		},

		// 			_getDialogBlock : function () {
		// if (!this._oDialogB) {
		// 		this._oDialogB = sap.ui.xmlfragment("blockFrag","com.prowess.zRDSFioriScreen.view.Block", this);
		// 		this.getView().addDependent(this._oDialogB);
		// 	}
		// 	return this._oDialogB;
		// },
				onBlock: function () {
					var that=this;
					that.loaddialog();
			this._oDialogB.open();
		},
		onSelectBlock1 :  function (oEvent1) {
				var st1=this.getView().byId("selectT1").getSelectedItem();
		var s1=	st1.mProperties.text;
				var id2,frgid;	
				if(s1=="Block"){
	 id2= "tableBlock1";
	 frgid="blockFrag";
					}else if(s1=="DataModel"){
					id2= "tableDataMod1";
					frgid="dataModelFrag";
							}else if(s1=="Template"){
						id2= "tableTemplate1";	
						frgid="templateFrag";
					}	
						var Bselected,Bdesc;
						var outcome4 = this.getView().byId("tDesc");
						var outcome3 = this.getView().byId("selectT3");
							   var oTable2 = sap.ui.core.Fragment.byId("templateFrag",id2);
						     var selectedItems = oTable2.getSelectedItems().map(function(item) {

 Bselected = item.mAggregations.cells[0].mProperties.text;
     Bdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
 this.firstfield=Bselected;
 this.firstfielddesc=Bdesc;
 this.dialogid1=id2;
 this.dialogfragid1=frgid;
// outcome3.setValue(Bselected);
// outcome4.setText(Bdesc);
},
onSelectBlock2 :  function (oEvent1) {
				var st2=this.getView().byId("selectB1").getSelectedItem();
					var s2=	st2.mProperties.text;
				var id2,frgid;	
				if(s2=="Block"){
	 id2= "tableBlock2";
	 frgid="blockFrag";
					}else if(s2=="DataModel"){
					id2= "tableDataMod2";
					frgid="dataModelFrag";
							}else if(s2=="Template"){
						id2= "tableTemplate2";	
						frgid="templateFrag";
					}	
						var Bselected,Bdesc;
						var outcome4 = this.getView().byId("bDesc");
						var outcome3 = this.getView().byId("selectB3");
							   var oTable2 = sap.ui.core.Fragment.byId("blockFrag",id2);
						     var selectedItems = oTable2.getSelectedItems().map(function(item) {

 Bselected = item.mAggregations.cells[0].mProperties.text;
     Bdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
// outcome3.setValue(Bselected);
// outcome4.setText(Bdesc);
 this.secondfield=Bselected;
 this.secondfielddesc=Bdesc;
  this.dialogid2=id2;
 this.dialogfragid2=frgid;
},
onSelectBlock3 :  function (oEvent1) {
			var st3=this.getView().byId("selectDM1").getSelectedItem();
					var s3=	st3.mProperties.text;
				var id2,frgid;	
				if(s3=="Block"){
	 id2= "tableBlock3";
	 frgid="blockFrag";
					}else if(s3=="DataModel"){
					id2= "tableDataMod3";
					frgid="dataModelFrag";
							}else if(s3=="Template"){
						id2= "tableTemplate3";	
						frgid="templateFrag";
					}	
						var Bselected,Bdesc;
						var outcome4 = this.getView().byId("dmDesc");
						var outcome3 = this.getView().byId("selectDM3");
							   var oTable2 = sap.ui.core.Fragment.byId("dataModelFrag",id2);
						     var selectedItems = oTable2.getSelectedItems().map(function(item) {

 Bselected = item.mAggregations.cells[0].mProperties.text;
     Bdesc = item.mAggregations.cells[1].mProperties.text; 
 
return item.mAggregations;

 });
// outcome3.setValue(Bselected);
// outcome4.setText(Bdesc);
this.thirdfield=Bselected;
 this.thirdfielddesc=Bdesc;
  this.dialogid3=id2;
 this.dialogfragid3=frgid;
},
onokB: function () {
		this.getView().byId("selectB3").setValue(this.secondfield);
		this.getView().byId("bDesc").setText(this.secondfielddesc);
		
		this._oDialogB.close();
		},
		onCloseB: function () {
				if(this.dialogfragid2!=undefined && this.dialogid2!=undefined)
			sap.ui.core.Fragment.byId(this.dialogfragid2,this.dialogid2).removeSelections(true);
		this._oDialogB.close();
		},	
					_getDialogBlockType : function () {
			if (!this._oDialogBT) {
				this._oDialogBT = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.BlockType", this);
				this.getView().addDependent(this._oDialogBT);
			}
			return this._oDialogBT;
		},
				onBlockType: function () {
			this._getDialogBlockType().open();
		},
				onSelectBlockType :  function (oEvent1) {
						var BTselected,BTdesc;
						var outcome6 = this.getView().byId("btDesc");
						var outcome5 = this.getView().byId("selectBT3");
							   var oTable3 = sap.ui.getCore().byId('tableBlockType');
						     var selectedItems = oTable3.getSelectedItems().map(function(item) {
						
	 BTselected = item.mAggregations.cells[0].mProperties.text;
     BTdesc = item.mAggregations.cells[1].mProperties.text; 
return item.mAggregations;

 });
outcome5.setValue(BTselected);
outcome6.setText(BTdesc);
},
						onCloseBT: function () {
		this._oDialogBT.close();
		},
		typechange1:function(){
			 var oTableBloc1= sap.ui.getCore().byId('tableBlockNew');
			 if(oTableBloc1!=undefined)
                oTableBloc1.removeSelections(true);    
                 
		},
		typechange2:function(){
                  var oTableDM1 = sap.ui.getCore().byId('tableDataModelNew');
                  if(oTableDM1!=undefined)
                oTableDM1.removeSelections(true);
		},
					_getDialogDataModel : function () {
			// if (!this._oDialogDM) {
			// 	this._oDialogDM = sap.ui.xmlfragment("dataModelFrag","com.prowess.zRDSFioriScreen.view.DataModel", this);
			// 	this.getView().addDependent(this._oDialogDM);
			// }
			// return this._oDialogDM;
		},
				onDataModel: function () {
					var that=this;
					that.loaddialog();
			this._oDialogDM.open();
		},
		onSelectDataModel1 :  function (oEvent1) {
					var st1=this.getView().byId("selectT1").getSelectedItem();
		var s1=	st1.mProperties.text;
				var id3,frgid;
				if(s1=="DataModel"){
					id3= "tableDataMod1";
					frgid="dataModelFrag";
					}else if(s1=="Block"){
						 id3= "tableBlock1";
						 frgid="blockFrag";
							}else if(s1=="Template"){
						id3= "tableTemplate1";
						frgid="templateFrag";
					}	
						var DMselected,DMdesc;
						var outcome8 = this.getView().byId("tDesc");
						var outcome7 = this.getView().byId("selectT3");
						   var oTable4 = sap.ui.core.Fragment.byId("templateFrag",id3);
						     var selectedItems = oTable4.getSelectedItems().map(function(item) {
 DMselected = item.mAggregations.cells[0].mProperties.text;
     DMdesc = item.mAggregations.cells[1].mProperties.text; 
return item.mAggregations;
 });
 
// outcome7.setValue(DMselected);
// outcome8.setText(DMdesc);
 this.firstfield=DMselected;
 this.firstfielddesc=DMdesc;
  this.dialogid1=id3;
 this.dialogfragid1=frgid;
},
onSelectDataModel2 :  function (oEvent1) {
						var st2=this.getView().byId("selectB1").getSelectedItem();
					var s2=	st2.mProperties.text;
				var id3,frgid;
				if(s2=="DataModel"){
					id3= "tableDataMod2";
					frgid="dataModelFrag";
					}else if(s2=="Block"){
						 id3= "tableBlock2";
						 frgid="blockFrag";
							}else if(s2=="Template"){
						id3= "tableTemplate2";
						frgid="templateFrag";
					}	
						var DMselected,DMdesc;
						var outcome8 = this.getView().byId("bDesc");
						var outcome7 = this.getView().byId("selectB3");
						   var oTable4 = sap.ui.core.Fragment.byId("blockFrag",id3);
						     var selectedItems = oTable4.getSelectedItems().map(function(item) {
 DMselected = item.mAggregations.cells[0].mProperties.text;
     DMdesc = item.mAggregations.cells[1].mProperties.text; 
return item.mAggregations;
 });
 
// outcome7.setValue(DMselected);
// outcome8.setText(DMdesc);
 this.secondfield=DMselected;
 this.secondfielddesc=DMdesc;
  this.dialogid2=id3;
 this.dialogfragid2=frgid;
},onSelectDataModel3 :  function (oEvent1) {
					var st3=this.getView().byId("selectDM1").getSelectedItem();
					var s3=	st3.mProperties.text;
				var id3,frgid;
				if(s3=="DataModel"){
					id3= "tableDataMod3";
					frgid="dataModelFrag";
					}else if(s3=="Block"){
						 id3= "tableBlock3";
						 frgid="blockFrag";
							}else if(s3=="Template"){
						id3= "tableTemplate3";
						frgid="templateFrag";
					}	
						var DMselected,DMdesc;
						var outcome8 = this.getView().byId("dmDesc");
						var outcome7 = this.getView().byId("selectDM3");
						   var oTable4 = sap.ui.core.Fragment.byId("dataModelFrag",id3);
						     var selectedItems = oTable4.getSelectedItems().map(function(item) {
 DMselected = item.mAggregations.cells[0].mProperties.text;
     DMdesc = item.mAggregations.cells[1].mProperties.text; 
return item.mAggregations;
 });
 
// outcome7.setValue(DMselected);
// outcome8.setText(DMdesc);
this.thirdfield=DMselected;
 this.thirdfielddesc=DMdesc;
  this.dialogid3=id3;
 this.dialogfragid3=frgid;
},
onokDM:function(){
	this.getView().byId("selectDM3").setValue(this.thirdfield);
	this.getView().byId("dmDesc").setText(this.thirdfielddesc);
	
	this._oDialogDM.close();
},
         onBlockChange:function () {
                var op2 = this.getView().byId("selectB3");
        var t3=    op2.mProperties.value;
                			var id2;
                			 if(t3=="Block"){
						 id2= "tableBlock2";
					}else if(t3=="DataModel"){
					id2= "tableDataMod2";
							}else if(t3=="Template"){
						id2= "tableTemplate2";		
					}
                if(t3!=this.Bselected){
                          var oTableBloc = sap.ui.getCore().byId(id2);
                          if(oTableBloc!=undefined)
                oTableBloc.removeSelections(true);
                }
        },
                onTemplateChange:function () {
            var op1 =this.getView().byId("selectT3");
        var t1=    op1.mProperties.value;
                if(t1!=this.Tselected){
                          var oTableTempl= sap.ui.getCore().byId('tableTemplate');
                           if(oTableTempl!=undefined)
                oTableTempl.removeSelections(true);
                }
        },
        onDataModelChange:function () {
                 var op4 = this.getView().byId("selectDM3");
        var t5=    op4.mProperties.value;
                	
				var id3;
	             if(t5=="DataModel"){
					id3= "tableDataMod3";
					}else if(t5=="Block"){
						 id3= "tableBlock3";
							}else if(t5=="Template"){
						id3= "tableTemplate3";		
					}
                if(t5!=this.DMselected){
                          var oTabledm = sap.ui.getCore().byId(id3);
                          if(oTabledm!=undefined)
                oTabledm.removeSelections(true);
                }
        },
        ChangeSelection1: function () {
	//	debugger;
	var that=this;
        	that.loaddialog();
				var st1=this.getView().byId("selectT1").getSelectedItem();
					var s1=	st1.mProperties.text;
					this.getView().byId("selectT3").setValue();
	if(s1=="Template"){
			sap.ui.core.Fragment.byId("templateFrag","tT1").setVisible(true);
		  sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").setVisible(true);
		  sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").removeSelections(true);
                        sap.ui.core.Fragment.byId("templateFrag","tableBlock1").setVisible(false);
                        sap.ui.core.Fragment.byId("templateFrag","tableBlock1").removeSelections(true);
                         sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").setVisible(false);
                         sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").removeSelections(true);
                         sap.ui.core.Fragment.byId("templateFrag","tB1").setVisible(false);
                      sap.ui.core.Fragment.byId("templateFrag","tDM1").setVisible(false);
					}else if(s1=="DataModel"){
						sap.ui.core.Fragment.byId("templateFrag","tDM1").setVisible(true);
                         sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").setVisible(true);
                         sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").removeSelections(true);
			sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").setVisible(false);  
			sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").removeSelections(true);
                sap.ui.core.Fragment.byId("templateFrag","tableBlock1").setVisible(false);
                sap.ui.core.Fragment.byId("templateFrag","tableBlock1").removeSelections(true);
                   sap.ui.core.Fragment.byId("templateFrag","tT1").setVisible(false);   
                      sap.ui.core.Fragment.byId("templateFrag","tB1").setVisible(false);
					}else if(s1=="Block"){
						sap.ui.core.Fragment.byId("templateFrag","tB1").setVisible(true);
                       sap.ui.core.Fragment.byId("templateFrag","tableBlock1").setVisible(true);
                        sap.ui.core.Fragment.byId("templateFrag","tableBlock1").removeSelections(true);
				 sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").setVisible(false);  
				  sap.ui.core.Fragment.byId("templateFrag","tableTemplate1").removeSelections(true);
                     sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").setVisible(false);
                      sap.ui.core.Fragment.byId("templateFrag","tableDataMod1").removeSelections(true);
                         sap.ui.core.Fragment.byId("templateFrag","tT1").setVisible(false); 
                    sap.ui.core.Fragment.byId("templateFrag","tDM1").setVisible(false);
					}
		},
			ChangeSelection2: function () {
				var that=this;
        	that.loaddialog();
			//		var outcome2 = this.getView().byId("selectB1");
				var st2=this.getView().byId("selectB1").getSelectedItem();
					var s2=	st2.mProperties.text;
					this.getView().byId("selectB3").setValue();
		/*			outcome2.setText(s2);
					console.log(outcome2);*/
	if(s2=="Block"){
                         sap.ui.core.Fragment.byId("blockFrag","tB2").setVisible(true);
                        sap.ui.core.Fragment.byId("blockFrag","tableBlock2").setVisible(true);
		sap.ui.core.Fragment.byId("blockFrag","tableTemplate2").setVisible(false);   
                        sap.ui.core.Fragment.byId("blockFrag","tableDataMod2").setVisible(false);
                         sap.ui.core.Fragment.byId("blockFrag","tT2").setVisible(false);  
                        sap.ui.core.Fragment.byId("blockFrag","tDM2").setVisible(false);
		  
					}else if(s2=="DataModel"){
                       sap.ui.core.Fragment.byId("blockFrag","tDM2").setVisible(true);
                       sap.ui.core.Fragment.byId("blockFrag","tableDataMod2").setVisible(true);
				sap.ui.core.Fragment.byId("blockFrag","tableTemplate2").setVisible(false);   
                        sap.ui.core.Fragment.byId("blockFrag","tableBlock2").setVisible(false);
                  sap.ui.core.Fragment.byId("blockFrag","tT2").setVisible(false);   
                         sap.ui.core.Fragment.byId("blockFrag","tB2").setVisible(false);
							}else if(s2=="Template"){
                     sap.ui.core.Fragment.byId("blockFrag","tT2").setVisible(true);   
			sap.ui.core.Fragment.byId("blockFrag","tableTemplate2").setVisible(true);   
                     sap.ui.core.Fragment.byId("blockFrag","tableBlock2").setVisible(false);
                  sap.ui.core.Fragment.byId("blockFrag","tableDataMod2").setVisible(false);
                       sap.ui.core.Fragment.byId("blockFrag","tB2").setVisible(false);
                        sap.ui.core.Fragment.byId("blockFrag","tDM2").setVisible(false);
					}
		},
		
		
		
		ChangeSelection3  : function () {
		//	debugger;
		var that=this;
        	that.loaddialog();
				var st3=this.getView().byId("selectDM1").getSelectedItem();
				this.getView().byId("selectDM3").setValue();
					var s3=	st3.mProperties.text;
					if(s3=="Block"){
                     sap.ui.core.Fragment.byId("dataModelFrag","tB3").setVisible(true);
                       sap.ui.core.Fragment.byId("dataModelFrag","tableBlock3").setVisible(true);
			sap.ui.core.Fragment.byId("dataModelFrag","tableTemplate3").setVisible(false);   
                         sap.ui.core.Fragment.byId("dataModelFrag","tableDataMod3").setVisible(false);
                         	sap.ui.core.Fragment.byId("dataModelFrag","tT3").setVisible(false);  
                    sap.ui.core.Fragment.byId("dataModelFrag","tDM3").setVisible(false);
					}else if(s3=="DataModel"){
                         sap.ui.core.Fragment.byId("dataModelFrag","tDM3").setVisible(true);
                   sap.ui.core.Fragment.byId("dataModelFrag","tableDataMod3").setVisible(true);
				 sap.ui.core.Fragment.byId("dataModelFrag","tableTemplate3").setVisible(false);   
                    sap.ui.core.Fragment.byId("dataModelFrag","tableBlock3").setVisible(false);
                   	 sap.ui.core.Fragment.byId("dataModelFrag","tT3").setVisible(false);   
                      sap.ui.core.Fragment.byId("dataModelFrag","tB3").setVisible(false);
					}else 	if(s3=="Template"){
                     	 sap.ui.core.Fragment.byId("dataModelFrag","tT3").setVisible(true);   
		 sap.ui.core.Fragment.byId("dataModelFrag","tableTemplate3").setVisible(true);   
                       sap.ui.core.Fragment.byId("dataModelFrag","tableBlock3").setVisible(false);
                      sap.ui.core.Fragment.byId("dataModelFrag","tableDataMod3").setVisible(false);
                        sap.ui.core.Fragment.byId("dataModelFrag","tB3").setVisible(false);
                      sap.ui.core.Fragment.byId("dataModelFrag","tDM3").setVisible(false);
					}
		},
        ChangeOperator1:function(oeve){
        	
         		var operator1=this.getView().byId("selectT2").getSelectedItem().getText();
         		var template=this.getView().byId("selectT1").getSelectedItem().getText();
         		var setkey=this.getView().byId("selectT2").getSelectedKey();
				this.getView().byId("selectT2").setSelectedKey(setkey);
				var id,frgid;
         		if(template=="DataModel"){
					id= "tableDataMod1";
					frgid="dataModelFrag";
					}else if(template=="Block"){
						 id= "tableBlock1";
						 frgid="blockFrag";
							}else if(template=="Template"){
						id= "tableTemplate1";
						frgid="templateFrag";
					}
        		if(operator1=="is empty"){
        			this.getView().byId("selectT3").setVisible(false);
        		}else{
        			this.getView().byId("selectT3").setVisible(true);
        			this.getView().byId("selectT3").setValue();
        			sap.ui.core.Fragment.byId(frgid,id).removeSelections(true);
        		}
        },
        ChangeOperator2:function(oeve){
        	
         		var operator2=this.getView().byId("selectB2").getSelectedItem().getText();
         		var template=this.getView().byId("selectB1").getSelectedItem().getText();
         		var setkey=this.getView().byId("selectB2").getSelectedKey();
				this.getView().byId("selectB2").setSelectedKey(setkey);
         			var id,frgid;
         		if(template=="DataModel"){
					id= "tableDataMod2";
					frgid="dataModelFrag";
					}else if(template=="Block"){
						 id= "tableBlock2";
						 frgid="blockFrag";
							}else if(template=="Template"){
						id= "tableTemplate2";
						frgid="templateFrag";
					}
        		if(operator2=="is empty"){
        			this.getView().byId("selectB3").setVisible(false);
        		}else{
        			this.getView().byId("selectB3").setVisible(true);
        			this.getView().byId("selectB3").setValue();
        			sap.ui.core.Fragment.byId(frgid,id).removeSelections(true);
        		}
        },
        ChangeOperator3:function(oeve){
        	
         		var operator3=this.getView().byId("selectDM2").getSelectedItem().getText();
				var template=this.getView().byId("selectDM1").getSelectedItem().getText();
				var setkey=this.getView().byId("selectDM2").getSelectedKey();
				this.getView().byId("selectDM2").setSelectedKey(setkey);
					var id,frgid;
         		if(template=="DataModel"){
					id= "tableDataMod3";
						frgid="dataModelFrag";
					}else if(template=="Block"){
						 id= "tableBlock3";
						 frgid="blockFrag";
							}else if(template=="Template"){
						id= "tableTemplate3";
						frgid="templateFrag";
					}
        		if(operator3=="is empty"){
        			this.getView().byId("selectDM3").setVisible(false);
        		}else{
        			this.getView().byId("selectDM3").setVisible(true);
        			this.getView().byId("selectDM3").setValue();
        			sap.ui.core.Fragment.byId(frgid,id).removeSelections(true);
        		}
        },
        onCloseDM: function () {
        		if(this.dialogfragid3!=undefined && this.dialogid3!=undefined)
        	sap.ui.core.Fragment.byId(this.dialogfragid3,this.dialogid3).removeSelections(true);
		this._oDialogDM.close();
		}	

	});
});