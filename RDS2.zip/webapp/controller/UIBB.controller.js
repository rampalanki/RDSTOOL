var templatedialogvlaue;
var blocktypedialogvalue;
var datamodeldialogvalue;
var btdescriptiondialogvalue;
var dmdialogvalue;
var attrseqArray;
var checkbutton;
sap.ui.define(["sap/m/Button",
		"sap/m/Label",
		"sap/m/Dialog",
		"sap/ui/core/Fragment",
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"jquery.sap.global",
	"sap/m/MessageBox"
], function (Button, Label, Dialog, Fragment, Controller, JSONModel, History, jQuery,MessageBox) {
	"use strict";

	return Controller.extend("com.prowess.zRDSFioriScreen.controller.UIBB", {
		onInit: function () {
			
			this.functionattribute = new JSONModel("model/functionattribute.json");
			this.getView().setModel(this.functionattribute,"function"); 
		
			this.application = new JSONModel("model/applicationattributes.json");
			this.getView().setModel(this.application,"application"); 
			
			this.sequencedata = new JSONModel("model/sequencedata.json");
			this.getView().setModel(this.sequencedata,"sequencedata");
		
			sap.ui.getCore()._mode = "repeat";
			this.temdescid1 = this.getView().byId("tdesc1");
			this.temdescid2 = this.getView().byId("tdesc2");
            sap.ui.getCore()._templateid = this.getView().byId("template");
            sap.ui.getCore()._btypeid = this.getView().byId("btype");
            sap.ui.getCore()._dmodelid = this.getView().byId("dmodel");
            sap.ui.getCore()._tdesc1id = this.getView().byId("tdesc1");
            sap.ui.getCore()._tdesc2id = this.getView().byId("tdesc2");
            sap.ui.getCore()._panelid1 = this.getView().byId("panel8");
            sap.ui.getCore()._panelid2 = this.getView().byId("panel9");
            this.paneltype = sap.ui.getCore()._blockdialogvalue;
            if(this.paneltype == "W"){
				this.getView().byId("panel8").setVisible(true);
			}
			if(this.paneltype == "R"){
				this.getView().byId("panel9").setVisible(true);
			}
            this.getView().byId("template").setValue(sap.ui.getCore()._templatedialogvlaue);
            this.getView().byId("btype").setValue(sap.ui.getCore()._blocktypedialogvalue);
            this.getView().byId("dmodel").setValue(sap.ui.getCore()._datamodeldialogvalue);
            this.getView().byId("tdesc1").setText(sap.ui.getCore()._btdescriptiondialogvalue);
            this.getView().byId("tdesc2").setText(sap.ui.getCore()._dmdialogvalue);
           
		
		},
		loadattribute:function(){
			this.attrseq = [];
			var sequencedata1 = this.sequencedata.getProperty("/attributesequence");
			for(var i = 0; i < sequencedata1.length; i++){
				 	if(sequencedata1[i].access == this.accseqvalue){
				 		this.attrseq.push({"access":sequencedata1[i].access,
				 							"sequence":sequencedata1[i].sequence,
				 							"attribute":sequencedata1[i].attribute,
				 							"description":sequencedata1[i].description
				 		});
				 	}
			}
			this.attrseqModel = new JSONModel();
			this.attrseqModel.setData({"attributesequence":this.attrseq});
			this.getView().setModel(this.attrseqModel,"attrseq");
		},
		loadconditional:function(){
			this.conditionalseq = [];
			var sequencedata2 = this.sequencedata.getProperty("/conditionalsequence");
			for(var i = 0; i < sequencedata2.length; i++){
				 	if(sequencedata2[i].access == this.accseqvalue){
				 		this.conditionalseq.push({"access":sequencedata2[i].access,"alias":sequencedata2[i].alias,"sequence":sequencedata2[i].sequence});
				 	}
			}
			this.conditionalModel = new JSONModel();
			this.conditionalModel.setData({"conditionalsequence":this.conditionalseq});
			this.getView().setModel(this.conditionalModel,"conditionalseq");
		},
		loadAttAccCond:function(){
			this.AttAccCondseq = [];
			var sequencedata3 = this.sequencedata.getProperty("/attaccsequence");
			for(var i = 0; i < sequencedata3.length; i++){
				 	if(sequencedata3[i].access == this.accseqvalue){
				 		this.AttAccCondseq.push({"access":sequencedata3[i].access,
				 								"attributesequence":sequencedata3[i].attributesequence,
				 								 "attributename":sequencedata3[i].attributename,
				 								 "attributevalue":sequencedata3[i].attributevalue
				 		});
				 	}
			}
			this.AttAccCondModel = new JSONModel();
			this.AttAccCondModel.setData({"attaccsequence":this.AttAccCondseq});
			this.getView().setModel(this.AttAccCondModel,"AttAccCondseq");
		},
		gettemplateform:function(){
			var panelid1,panelid2;
			this.paneltype = sap.ui.getCore()._blockdialogvalue;
			panelid1 = sap.ui.getCore().panelid1;
			panelid2 = sap.ui.getCore().panelid2;
			if(this.paneltype == "W"){
				panelid1.setVisible(true);
				panelid2.setVisible(false);
			}
			if(this.paneltype == "R"){
				panelid1.setVisible(false);
				panelid2.setVisible(true);
			}
            var temid = sap.ui.getCore().byId(sap.ui.getCore().templateid);
            var btid = sap.ui.getCore().byId(sap.ui.getCore().btypeid);
            var dmid = sap.ui.getCore().byId(sap.ui.getCore().dmodelid);
            var td1id = sap.ui.getCore().byId(sap.ui.getCore().tdesc1id);
            var td2id = sap.ui.getCore().byId(sap.ui.getCore().tdesc2id);
            temid.setValue(sap.ui.getCore()._templatedialogvlaue);
            btid.setValue(sap.ui.getCore()._blocktypedialogvalue);
            dmid.setValue(sap.ui.getCore()._datamodeldialogvalue);
            td1id.setText(sap.ui.getCore()._btdescriptiondialogvalue);
            td2id.setText(sap.ui.getCore()._dmdialogvalue);
		},
		AccseqOpenDialog: function (oEvent) {
								 if (!this._oDialog) {
        					  this._oDialog = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.accessSeq",this);
        					  this.getView().addDependent(this._oDialog);
        				 }
        				 return this._oDialog.open();
		},
		AttseqOpenDialog: function (oEvent) {
						 if (!this._oDialog1) {
        					  this._oDialog1 = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.attributeSeq",this);
        					  this.getView().addDependent(this._oDialog1);
        				 }
        				 return this._oDialog1.open();
		},
		ConditionalseqOpenDialog: function (oEvent) {
							 if (!this._oDialog2) {
        					  this._oDialog2 = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.ConSeq",this);
        					  this.getView().addDependent(this._oDialog2);
        				 }
        				 return this._oDialog2.open();
		},
		AccAttseqOpenDialog: function (oEvent) {
							 if (!this._oDialog3) {
        					  this._oDialog3 = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.accattSeq",this);
        					  this.getView().addDependent(this._oDialog3);
        				 }
        				 return this._oDialog3.open();
		},
		setaccsequencecloseDialog:function(){
			 this._oDialog.close();
			 sap.ui.getCore().byId("accseq").setValue();
			sap.ui.getCore().byId("accerr").setVisible(false);
		},
		setattsequencecloseDialog:function(){
			 this._oDialog1.close();
			 sap.ui.getCore().byId("attseq").setValue();
			sap.ui.getCore().byId("attseq1").setValue();
			sap.ui.getCore().byId("atterr").setVisible(false);
			sap.ui.getCore().byId("atterr1").setVisible(false);
		},
		setconsequencecloseDialog:function(){
			 this._oDialog2.close();
			 sap.ui.getCore().byId("Condseq1").setValue();
			sap.ui.getCore().byId("Condseq2").setValue();
			sap.ui.getCore().byId("conseqerr1").setVisible(false);
			sap.ui.getCore().byId("conseqerr2").setVisible(false);
		},
		setaccattsequencecloseDialog:function(){
			 this._oDialog3.close();
			 sap.ui.getCore().byId("accattseq").setValue();
			 sap.ui.getCore().byId("accattseq1").setValue();
			sap.ui.getCore().byId("accatterr").setVisible(false);
		},
		attributechange:function(oevent){
			var that=this;
			this.getView().byId("attseqdel").setEnabled(true);
            this.getView().byId("attseqcopy").setEnabled(true);
			this.attseqvalue = oevent.mParameters.listItems[0].mAggregations.cells[0].mProperties.text;
			that.setattacccondpanel();
		},
		conditionalchange:function(oevent){
			var that=this;
			this.getView().byId("conseqdel").setEnabled(true);
            this.getView().byId("conseqcopy").setEnabled(true);
			this.condaliasvalue = oevent.mParameters.listItems[0].mAggregations.cells[0].mProperties.text;
			this.condseqvalue = oevent.mParameters.listItems[0].mAggregations.cells[1].mProperties.text;
			that.setattacccondpanel();
		},
		AccAttCondChange:function(){
			this.getView().byId("accattseqdel").setEnabled(true);
            this.getView().byId("accattseqcopy").setEnabled(true);
		},
		setpanelhtext:function(oevent){
			var that = this;
			that.accseqvalue = oevent.mParameters.listItems[0].mAggregations.cells[0].mProperties.text;
			this.getView().byId("accseqdel").setEnabled(true);
            this.getView().byId("accseqcopy").setEnabled(true);
			this.getView().byId("panel3").setHeaderText("BRF Control Attributes - Access Seq " + that.accseqvalue);
            this.getView().byId("panel4").setHeaderText("Attributes - Access Seq " + that.accseqvalue);
            this.getView().byId("panel5").setHeaderText("Data Changes - Access Seq " + that.accseqvalue);
            this.getView().byId("panel6").setHeaderText("Condition Sequence - Access Seq " + that.accseqvalue);
            this.changevalue="setpanelhtext";
			that.loadattribute();
			that.loadconditional();
			that.loadAttAccCond();
			this.attseqvalue="";this.condaliasvalue="";this.condseqvalue="";
			that.setattacccondpanel();
		},
		setattacccondpanel:function(){
			var that=this;
			if(this.attseqvalue==undefined)
			this.attseqvalue="";
			if(this.condaliasvalue==undefined)
			this.condaliasvalue="";
			if(this.condseqvalue==undefined)
			this.condseqvalue="";
			this.getView().byId("panel7").setHeaderText("Attribute Value Access Seq " + this.attseqvalue + "/ Condition Alias " +this.condaliasvalue+ "/ Condition Seq " + this.condseqvalue);
		},
		setaccsequence:function(){
			this.taccsequence = sap.ui.getCore().byId("accseq").getValue();
			sap.ui.getCore().byId("accerr").setVisible(false);
			var oTable = this.getView().byId("comtable1");
			if(this.taccsequence != ""){
				if(TableLen != 0){
					for(var i = 0; i < oTable.getItems().length; i++){
						if(this.taccsequence == oTable.getItems()[i].mAggregations.cells[0].mProperties.text){
							MessageBox.alert("Sequence Existed");
							sap.ui.getCore().byId("accseq").setValue();
							return false;
						}
					}
				}
			 var oItem = new sap.m.ColumnListItem({
            cells: [ new sap.m.Label({text: this.taccsequence }),
            		 new sap.m.Input({editable:true}),
            		 new sap.m.Input({editable:true})]
            });
             if(oTable.getItems().length == 0 || oTable.getItems().length != 0){
            	this.getView().byId("panel3").setHeaderText("BRF Control Attributes - Access Seq " + this.taccsequence);
            	this.getView().byId("panel4").setHeaderText("Attributes - Access Seq " + this.taccsequence);
            	this.getView().byId("panel5").setHeaderText("Data Changes - Access Seq " + this.taccsequence);
            	this.getView().byId("panel6").setHeaderText("Condition Sequence - Access Seq " + this.taccsequence);
            }
            oTable.addItem(oItem);
            this.getView().byId("accseqdel").setEnabled(true);
            this.getView().byId("accseqcopy").setEnabled(true);
			this._oDialog.close();
			sap.ui.getCore().byId("accseq").setValue();
			sap.ui.getCore().byId("accerr").setVisible(false);
			}else{
			sap.ui.getCore().byId("accerr").setVisible(true);
			}
				
				var TableLen = oTable.getItems().length;
				var fi = oTable.getItems()[TableLen - 1];
            	oTable.setSelectedItem(fi,true);
            	this.newattr1=[];this.newcond1=[];this.newaccattcond1=[];
            	this.attrseqModel.setData({"attributesequence":this.newattr1});
            	this.conditionalModel.setData({"conditionalsequence":this.newcond1});
            	this.AttAccCondModel.setData({"attaccsequence":this.newaccattcond1});
            	this.getView().byId("panel7").setHeaderText("Attribute Value Access Seq " + "/ Condition Alias " + "/ Condition Seq ");
			},
		setattsequence:function(){
			var that=this;
			this.tattsequence1 = sap.ui.getCore().byId("attseq").getValue();
			this.tattsequence2 = sap.ui.getCore().byId("attseq1").getValue();
			sap.ui.getCore().byId("atterr").setVisible(false);
			sap.ui.getCore().byId("atterr1").setVisible(false);
			if(this.tattsequence1 != "" && this.tattsequence2 != ""){
				var oTable = this.getView().byId("comtable2");
					if(oTable.getItems().length != 0){
						console.log(oTable.getItems()[0].mAggregations.cells[0].mProperties.text);
					for(var i = 0; i < oTable.getItems().length; i++){
						if(this.tattsequence1 == oTable.getItems()[i].mAggregations.cells[0].mProperties.text){
							MessageBox.alert("Sequence Existed");
							sap.ui.getCore().byId("attseq").setValue();
							sap.ui.getCore().byId("attseq1").setValue();
							return false;
						}
					}
				}
			 var oItem = new sap.m.ColumnListItem({
            cells: [ new sap.m.Label({text: this.tattsequence1 }),
            		 new sap.m.Label({text: this.tattsequence2}),
            		 new sap.m.Input({editable:true})]
            });
            
            oTable.addItem(oItem);
            this.getView().byId("attseqdel").setEnabled(true);
            this.getView().byId("attseqcopy").setEnabled(true);
			this._oDialog1.close();
			sap.ui.getCore().byId("attseq").setValue();
			sap.ui.getCore().byId("attseq1").setValue();
			sap.ui.getCore().byId("atterr").setVisible(false);
			sap.ui.getCore().byId("atterr1").setVisible(false);
			}else{
				if(this.tattsequence1 == ""){
			sap.ui.getCore().byId("atterr").setVisible(true);
				}
				if(this.tattsequence2 == ""){
			sap.ui.getCore().byId("atterr1").setVisible(true);
				}
			}
				var TableLen = oTable.getItems().length;
				var fi = oTable.getItems()[TableLen - 1];
            	oTable.setSelectedItem(fi,true);
            	this.attseqvalue=this.tattsequence1;
            	that.setattacccondpanel();
		},
		setconsequence:function(){
			var that=this;
			this.consequence1 = sap.ui.getCore().byId("Condseq1").getValue();
			this.consequence2 = sap.ui.getCore().byId("Condseq2").getValue();
			sap.ui.getCore().byId("conseqerr1").setVisible(false);
			sap.ui.getCore().byId("conseqerr2").setVisible(false);
			if(this.consequence1 != "" && this.consequence2 != ""){
				 var oTable = this.getView().byId("comtable4");
				 	if(oTable.getItems().length != 0){
				 		console.log(oTable.getItems()[0].mAggregations);
					for(var i = 0; i < oTable.getItems().length; i++){
						if(this.consequence2 == oTable.getItems()[i].mAggregations.cells[1].mProperties.text){
							MessageBox.alert("Sequence Existed");
							sap.ui.getCore().byId("Condseq1").setValue();
							sap.ui.getCore().byId("Condseq2").setValue();
							return false;
						}
					}
				}
			 var oItem = new sap.m.ColumnListItem({
            cells: [ new sap.m.Label({text:this.consequence1}),
            		 new sap.m.Label({text:this.consequence2})]
            });
           
            oTable.addItem(oItem);
            this.getView().byId("conseqdel").setEnabled(true);
            this.getView().byId("conseqcopy").setEnabled(true);
			this._oDialog2.close();
			sap.ui.getCore().byId("Condseq1").setValue();
			sap.ui.getCore().byId("Condseq2").setValue();
			sap.ui.getCore().byId("conseqerr1").setVisible(false);
			sap.ui.getCore().byId("conseqerr2").setVisible(false);
			}else{
				if(this.consequence1 == ""){
			sap.ui.getCore().byId("conseqerr1").setVisible(true);
				}
				if(this.consequence2 == ""){
					sap.ui.getCore().byId("conseqerr2").setVisible(true);
				}
			}
			var TableLen = oTable.getItems().length;
				var fi = oTable.getItems()[TableLen - 1];
            	oTable.setSelectedItem(fi,true);
            this.condaliasvalue=this.consequence1;	
            this.condseqvalue=this.consequence2;
            that.setattacccondpanel();
		},
		setaccattsequence:function(){
			this.accattsequence = sap.ui.getCore().byId("accattseq").getValue();
			this.accattname = sap.ui.getCore().byId("accattseq1").getValue();
			sap.ui.getCore().byId("accatterr").setVisible(false);
			sap.ui.getCore().byId("accatterr1").setVisible(false);
			if(this.accattsequence != "" && this.accattname != ""){
				var oTable = this.getView().byId("comtable3");
					if(oTable.getItems().length != 0){
							console.log(oTable.getItems()[0].mAggregations.cells[0].mProperties.text);
					for(var i = 0; i < oTable.getItems().length; i++){
						if(this.accattsequence == oTable.getItems()[i].mAggregations.cells[0].mProperties.text){
							MessageBox.alert("Sequence Existed");
							sap.ui.getCore().byId("accattseq").setValue();
							sap.ui.getCore().byId("accattseq1").setValue();
							return false;
						}
					}
				}
			 var oItem = new sap.m.ColumnListItem({
            cells: [ new sap.m.Label({text: this.accattsequence }),
            		 new sap.m.Label({text: this.accattname}),
            		 new sap.m.Input({editable:true})]
            });
            
            oTable.addItem(oItem);
            this.getView().byId("accattseqdel").setEnabled(true);
            this.getView().byId("accattseqcopy").setEnabled(true);
			this._oDialog3.close();
			sap.ui.getCore().byId("accattseq").setValue();
			sap.ui.getCore().byId("accatterr").setVisible(false);
			sap.ui.getCore().byId("accattseq1").setValue();
			sap.ui.getCore().byId("accatterr1").setVisible(false);
		}else{
			if(this.accattsequence == ""){
			sap.ui.getCore().byId("accatterr").setVisible(true);
			}
			if(this.accattname == ""){
			sap.ui.getCore().byId("accatterr1").setVisible(true);
			}
			}
		},
		expandall:function(){
					 this.getView().byId("panel1").setExpanded(true);
					 this.getView().byId("panel2").setExpanded(true);
					 this.getView().byId("panel3").setExpanded(true);
					 this.getView().byId("panel4").setExpanded(true);
					 this.getView().byId("panel5").setExpanded(true);
					 this.getView().byId("panel6").setExpanded(true);
					 this.getView().byId("panel7").setExpanded(true);
					 this.getView().byId("panel8").setExpanded(true);
					 this.getView().byId("panel9").setExpanded(true);
					 
		},
		collapseall:function(){
					 this.getView().byId("panel1").setExpanded(false);
					 this.getView().byId("panel2").setExpanded(false);
					 this.getView().byId("panel3").setExpanded(false);
					 this.getView().byId("panel4").setExpanded(false);
					 this.getView().byId("panel5").setExpanded(false);
					 this.getView().byId("panel6").setExpanded(false);
					 this.getView().byId("panel7").setExpanded(false);
					 this.getView().byId("panel8").setExpanded(false);
					 this.getView().byId("panel9").setExpanded(false);
					
		},
		validationcheck:function(){ 
			console.log(checkbutton);
					 this.getView().byId("panel1").setExpanded(true);
					 this.getView().byId("panel2").setExpanded(true);
					 this.getView().byId("panel3").setExpanded(true);
					 this.getView().byId("panel4").setExpanded(true);
					 this.getView().byId("panel5").setExpanded(true);
					 this.getView().byId("panel6").setExpanded(true);
					 this.getView().byId("panel7").setExpanded(true);
					 this.getView().byId("panel8").setExpanded(true);
					 this.getView().byId("panel9").setExpanded(true);
			
					if(this.getView().byId("desc").getValue() == ""){
						this.getView().byId("valid1").setVisible(true);
						this.getView().byId("desc").setValueState("Error");
					}else{
						if(checkbutton == "save"){
							
						}else{
							MessageBox.warning(	"No Errors Found");
						}
					}
					 //this.getView().byId("panel2").getValue();
					 //this.getView().byId("panel3").getValue();
					 //this.getView().byId("panel4").getValue();
					 //this.getView().byId("panel5").getValue();
					 //this.getView().byId("panel6").getValue();
					 //this.getView().byId("panel7").getValue();
					 //this.getView().byId("panel8").getValue();
					 //this.getView().byId("panel9").getValue();
		},
		saveUIBB:function(){
			var that = this;
			checkbutton = "save";
			 this.getView().byId("panel1").setExpanded(true);
					 this.getView().byId("panel2").setExpanded(true);
					 this.getView().byId("panel3").setExpanded(true);
					 this.getView().byId("panel4").setExpanded(true);
					 this.getView().byId("panel5").setExpanded(true);
					 this.getView().byId("panel6").setExpanded(true);
					 this.getView().byId("panel7").setExpanded(true);
					 this.getView().byId("panel8").setExpanded(true);
					 this.getView().byId("panel9").setExpanded(true);
			that.validationcheck();
		},
		deletewarning:function(){
			var that = this;
				MessageBox.warning(
				"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
					that.handleDelete();
					}
				}
			);
				},
		accdeletewarning:function(){
			var that=this;
			var oTable1 = this.getView().byId("comtable1");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
			MessageBox.warning(	"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						console.log(sAction);
						if(sAction=="OK"){
							that.accseqDelete();
						}else{
							return false;
						}
					}
				}
			);
				}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		accseqDelete : function (oeve) {
			this.accseqflag = 1;
				var oTable1 = this.getView().byId("comtable1");
				var oTable2 = this.getView().byId("comtable2");
				var oTable3 = this.getView().byId("comtable4");
				var oTable4 = this.getView().byId("comtable3");
				 var aSelectedItems = oTable1.getSelectedItems();
				 var fi;this.newattr=[];var attfiltervalue;var tab2SelectedItem,tab3SelectedItem1,tab3SelectedItem2;
				if(aSelectedItems != ""){
				 for(var i = 0; i < aSelectedItems.length; i++){
				 	var idx = oTable1.indexOfItem(aSelectedItems[i]);
					   oTable1.removeItem(aSelectedItems[i]);
					   if(idx > 0){
					   fi = oTable1.getItems()[0];
					   }else if(idx == 0){
					   	fi = oTable1.getItems()[idx];
					   }
					   oTable1.setSelectedItem(fi,true);
					   if(fi==undefined){
            				attfiltervalue="";
            			}else{
            			 attfiltervalue=oTable1.getSelectedItem().mAggregations.cells[0].mProperties.text;
            			}
            			var sequencedata1=this.sequencedata.getProperty("/attributesequence");
            			for(var j = 0; j < sequencedata1.length; j++){
				 		if(sequencedata1[j].access != aSelectedItems[i].mAggregations.cells[0].mProperties.text && sequencedata1[j].access==attfiltervalue){
				 				this.newattr.push({"access":sequencedata1[j].access,
				 							"sequence":sequencedata1[j].sequence,
				 							"attribute":sequencedata1[j].attribute,
				 							"description":sequencedata1[j].description
				 		});
				 	}
				 	}
				 	this.attrseqModel.setData({"attributesequence":this.newattr});
				 	this.newcond=[];
				 	var sequencedata2=this.sequencedata.getProperty("/conditionalsequence");
				 	for(var k = 0; k < sequencedata2.length; k++){
				 		if(sequencedata2[k].access != aSelectedItems[i].mAggregations.cells[0].mProperties.text && sequencedata2[k].access==attfiltervalue){
				 					this.newcond.push({"access":sequencedata2[k].access,
				 												"alias":sequencedata2[k].alias,
				 												"sequence":sequencedata2[k].sequence
				 					});
				 	}
				 	}
				 	this.conditionalModel.setData({"conditionalsequence":this.newcond});
				 	this.newaccattcond=[];
				 	var sequencedata3=this.sequencedata.getProperty("/attaccsequence");
				 	for(var m = 0; m < sequencedata3.length; m++){
				 		if(sequencedata3[m].access != aSelectedItems[i].mAggregations.cells[0].mProperties.text && sequencedata3[m].access==attfiltervalue){
				 						this.newaccattcond.push({"access":sequencedata3[m].access,
				 								"attributesequence":sequencedata3[m].attributesequence,
				 								 "attributename":sequencedata3[m].attributename,
				 								 "attributevalue":sequencedata3[m].attributevalue
				 	});
				 		}
				 	}
				 	this.AttAccCondModel.setData({"attaccsequence":this.newaccattcond});
				 }
					if(oTable2.getSelectedItem()!=null){
					  tab2SelectedItem = oTable2.getSelectedItem().mAggregations.cells[0].mProperties.text;
					}else{
						tab2SelectedItem="";
					}
					if(oTable3.getSelectedItem()!=null){
					  tab3SelectedItem1 = oTable3.getSelectedItem().mAggregations.cells[0].mProperties.text;
					   tab3SelectedItem2 = oTable3.getSelectedItem().mAggregations.cells[1].mProperties.text;
					}else{
						tab3SelectedItem1 ="";
					   tab3SelectedItem2="";
					}
				this.getView().byId("panel3").setHeaderText("BRF Control Attributes - Access Seq " + attfiltervalue);
				this.getView().byId("panel4").setHeaderText("Attributes - Access Seq " + attfiltervalue);
            	this.getView().byId("panel5").setHeaderText("Data Changes - Access Seq " + attfiltervalue);
            	this.getView().byId("panel6").setHeaderText("Condition Sequence - Access Seq " + attfiltervalue);
            	this.getView().byId("panel7").setHeaderText("Attribute Value Access Seq "+tab2SelectedItem + "/ Condition Alias "+tab3SelectedItem1 + "/ Condition Seq "+tab3SelectedItem2);
						var bCopy =	this.getView().byId("accseqcopy");
						var bDelete =	this.getView().byId("accseqdel");
		    		if(oTable1.getItems() == ""){
		    			bCopy.setEnabled(false);
					bDelete.setEnabled(false); 
		    		}
			}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		attdeletewarning:function(){
			var that=this;
			var oTable1 = this.getView().byId("comtable2");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
			MessageBox.warning(	"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						console.log(sAction);
						if(sAction=="OK"){
							that.attseqDelete();
						}else{
							return false;
						}
					}
				}
			);
				}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		attseqDelete : function (oeve) {
			var that=this;
				var oTable1 = this.getView().byId("comtable2");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
			  var delitems=[];
			  var modelData = this.attrseqModel.getProperty("/attributesequence");
				 for(var i=0;i<modelData.length;i++){
				 	for(var j=0;j<aSelectedItems.length;j++){
				 		var idx = oTable1.indexOfItem(aSelectedItems[j]);
				 	if(modelData[i].sequence!=aSelectedItems[j].mAggregations.cells[0].mProperties.text){
				 		delitems.push({"access":modelData[i].access,
				 								"sequence":modelData[i].sequence,
				 								 "attribute":modelData[i].attribute,
				 								 "description":modelData[i].description
				 	});
				 	}
				 	}
				 } 
				 	this.attrseqModel.setData({"attributesequence":delitems});
					this.getView().setModel(this.attrseqModel,"attrseq");
					var fi;
					  if(idx > 0){
					  fi = oTable1.getItems()[0];
					  }else if(idx == 0){
					  	fi = oTable1.getItems()[idx];
					  }
            			oTable1.setSelectedItem(fi,true);
            			if(fi==undefined){
            				this.tattsequence1="";
            			}else{
            			this.tattsequence1=oTable1.getSelectedItem().mAggregations.cells[0].mProperties.text;
            			}
            	this.attseqvalue=this.tattsequence1;
            	that.setattacccondpanel();
             var mainData = this.sequencedata.getProperty("/attributesequence");
				 for(var l=0;l<mainData.length;l++){
				 	for(var k=0;k<aSelectedItems.length;k++){
				 	if(mainData[l].sequence==aSelectedItems[k].mAggregations.cells[0].mProperties.text){
				 		mainData.splice(l,1);
				 	}
				 	}
				 } 
				var bCopy =	this.getView().byId("attseqcopy");
				var bDelete =	this.getView().byId("attseqdel");
		    		if(oTable1.getItems() == ""){
		    		bCopy.setEnabled(false);
					bDelete.setEnabled(false); 
		    		}
			}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		conddeletewarning:function(){
			var that=this;
			var oTable1 = this.getView().byId("comtable4");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
			MessageBox.warning(	"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						console.log(sAction);
						if(sAction=="OK"){
							that.condseqDelete();
						}else{
							return false;
						}
					}
				}
			);
				}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		condseqDelete : function (oeve) {
			var that=this;
				var oTable1 = this.getView().byId("comtable4");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
					 var delitems=[];
			  var modelData = this.conditionalModel.getProperty("/conditionalsequence");
				 for(var i=0;i<modelData.length;i++){
				 	for(var j=0;j<aSelectedItems.length;j++){
				 		var idx = oTable1.indexOfItem(aSelectedItems[j]);
				 	if(modelData[i].sequence!=aSelectedItems[j].mAggregations.cells[1].mProperties.text){
				 		delitems.push({ "access":modelData[i].access,
				 						"alias":modelData[i].alias,
				 						"sequence":modelData[i].sequence
				 	});
				 	}
				 	}
				 } 
				 	this.conditionalModel.setData({"conditionalsequence":delitems});
					this.getView().setModel(this.conditionalModel,"conditionalseq");
					var fi;
					   if(idx > 0){
					   fi = oTable1.getItems()[0];
					   }else if(idx == 0){
					   	fi = oTable1.getItems()[idx];
					   }
            			oTable1.setSelectedItem(fi,true);
            			if(fi==undefined){
            				this.consequence1="";
            				this.consequence2="";
            			}else{
            			this.consequence1=oTable1.getSelectedItem().mAggregations.cells[0].mProperties.text;
            			this.consequence2=oTable1.getSelectedItem().mAggregations.cells[1].mProperties.text;
            			}
            			this.condaliasvalue=this.consequence1;	
            this.condseqvalue=this.consequence2;
            that.setattacccondpanel();
             var mainData = this.sequencedata.getProperty("/conditionalsequence");
				 for(var l=0;l<mainData.length;l++){
				 	for(var k=0;k<aSelectedItems.length;k++){
				 	if(mainData[l].sequence==aSelectedItems[k].mAggregations.cells[1].mProperties.text){
				 		mainData.splice(l,1);
				 	}
				 	}
				 }
						var bCopy =	this.getView().byId("conseqcopy");
						var bDelete =	this.getView().byId("conseqdel");
		    		if(oTable1.getItems() == ""){
		    			bCopy.setEnabled(false);
					bDelete.setEnabled(false); 
		    		}
			}
		},
		accattdeletewarning:function(){
			var that=this;
			var oTable1 = this.getView().byId("comtable3");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
			MessageBox.warning(	"Are you sure want to delete?",
				{
					actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
					onClose: function(sAction) {
						console.log(sAction);
						if(sAction=="OK"){
							that.accattseqDelete();
						}else{
							return false;
						}
					}
				}
			);
				}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		accattseqDelete : function (oeve) {
				var oTable1 = this.getView().byId("comtable3");
				 var aSelectedItems = oTable1.getSelectedItems();
				if(aSelectedItems != ""){
				 var delitems=[];
			  var modelData = this.AttAccCondModel.getProperty("/attaccsequence");
				 for(var i=0;i<modelData.length;i++){
				 	for(var j=0;j<aSelectedItems.length;j++){
				 		var idx = oTable1.indexOfItem(aSelectedItems[j]);
				 	if(modelData[i].attributesequence!=aSelectedItems[j].mAggregations.cells[0].mProperties.text){
				 		delitems.push({"access":modelData[i].access,
				 								"attributesequence":modelData[i].attributesequence,
				 								 "attributename":modelData[i].attributename,
				 								 "attributevalue":modelData[i].attributevalue,
				 	});
				 	}
				 	}
				 }
				 	this.AttAccCondModel.setData({"attaccsequence":delitems});
					this.getView().setModel(this.AttAccCondModel,"AttAccCondseq");
             var mainData = this.sequencedata.getProperty("/attaccsequence");
				 for(var l=0;l<mainData.length;l++){
				 	for(var k=0;k<aSelectedItems.length;k++){
				 	if(mainData[l].attributesequence==aSelectedItems[k].mAggregations.cells[0].mProperties.text){
				 		mainData.splice(l,1);
				 	}
				 	}
				 } 
						var bCopy =	this.getView().byId("accattseqcopy");
						var bDelete =	this.getView().byId("accattseqdel");
		    		if(oTable1.getItems() == ""){
		    			bCopy.setEnabled(false);
					bDelete.setEnabled(false); 
		    		}
			}else{
			MessageBox.alert("Please Select item from table.");
			}
		},
		errhide:function(){
			if(this.getView().byId("desc").getValue() != ""){
			this.getView().byId("valid1").setVisible(false);
			this.getView().byId("desc").setValueState("None");
			}else{
			this.getView().byId("valid1").setVisible(true);	
			}
		},
		functionatt:function(){
				if (!this._oDialogafun) {
				this._oDialogafun = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.function", this);
				this.getView().addDependent(this._oDialogafun);
			}
			this._oDialogafun.open();
		},
		onfunctionatt :  function (oEvent1) {
						var banvalue,bandescription;
						var ban = this.getView().byId("ban");
						var ban1 = this.getView().byId("ban1");
						var oTable1 = sap.ui.getCore().byId("FunctiontableBRF");
					var selectedItems = oTable1.getSelectedItems().map(function(item) {
					banvalue = item.mAggregations.cells[0].mProperties.text;
    				bandescription = item.mAggregations.cells[1].mProperties.text; 
				return item.mAggregations;
			});
			ban.setValue(bandescription);
			ban1.setValue(banvalue);
			this._oDialogafun.close();
		},
		onfunctionattclose:function(){
				this._oDialogafun.close();
		},
		applicationatt:function(){
				if (!this._oDialogaapp) {
				this._oDialogaapp = sap.ui.xmlfragment("com.prowess.zRDSFioriScreen.view.application", this);
				this.getView().addDependent(this._oDialogaapp);
			}
			this._oDialogaapp.open();
		},
		onapplicationatt :  function (oEvent1) {
						var ban1value,ban1description;
						var ban = this.getView().byId("ban");
						var ban1 = this.getView().byId("ban1");
						var oTable1 = sap.ui.getCore().byId("ApplicationtableBRF");
					var selectedItems = oTable1.getSelectedItems().map(function(item) {
					ban1value = item.mAggregations.cells[0].mProperties.text;
    				ban1description = item.mAggregations.cells[1].mProperties.text; 
				return item.mAggregations;
			});
			ban.setValue(ban1value);
			ban1.setValue(ban1description);
			this._oDialogaapp.close();
		},
		onapplicationattclose:function(){
				this._oDialogaapp.close();
		},
		NavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			this.getView().byId("valid1").setVisible(false);
			this.temdescid1.setText();
			this.temdescid2.setText();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Search", true);
			}
		}
		
	});
});
