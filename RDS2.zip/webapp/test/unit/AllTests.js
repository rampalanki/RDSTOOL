sap.ui.define([
	"com/prowess/zRDSFioriScreen/test/unit/controller/SearchView.controller"
], function () {
	"use strict";
});