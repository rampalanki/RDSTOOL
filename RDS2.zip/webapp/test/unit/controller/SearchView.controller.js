/*global QUnit*/

sap.ui.define([
	"com/prowess/zRDSFioriScreen/controller/SearchView.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SearchView Controller");

	QUnit.test("I should test the SearchView controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});